
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import VacancyCard from './components/VacancyCard';
import AIChatBot from './components/AIChatBot';
import { RENTROP_VACANCY, NAVIGATION_STRUCTURE } from './constants';
import { PAGE_CONTENT } from './data/pages';

const App: React.FC = () => {
  const [currentPath, setCurrentPath] = useState<string>('главная');

  // Handle back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname.split('/').pop() || 'главная';
      setCurrentPath(decodeURIComponent(path).toLowerCase());
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateTo = (path: string) => {
    const lowerPath = path.toLowerCase();
    if (lowerPath === 'главная') {
      window.history.pushState({}, '', '/');
      setCurrentPath('главная');
    } else {
      const cleanPath = lowerPath.replace(/\s+/g, '-');
      window.history.pushState({}, '', `/${cleanPath}`);
      setCurrentPath(cleanPath);
    }
    window.scrollTo(0, 0);
  };

  const handleApplyClick = () => {
    if (currentPath !== 'главная') {
      // If we are on a subpage, go home first then scroll
      navigateTo('главная');
      setTimeout(() => {
        document.getElementById('apply')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById('apply')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const renderHome = () => (
    <>
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-yellow-500/10 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px]"></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black uppercase tracking-tighter leading-none">
              Вакансия Эксперт <br/>
              <span className="text-yellow-500">(РентРОП)</span>
            </h1>
            <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto font-medium">
              Присоединяйся к команде, которая меняет правила игры в управлении продажами. 
              Мы ищем сильных лидеров для работы в масштабных проектах.
            </p>
            
            <div className="pt-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="glass-effect p-2 rounded-[32px] border border-white/10 overflow-hidden shadow-2xl">
                <div className="relative pt-[56.25%]">
                  <iframe 
                    className="absolute inset-0 w-full h-full rounded-2xl"
                    src="https://www.youtube.com/embed/Fxdu8GmYSzg" 
                    title="Описание сайта"
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="p-4 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  Описание сайта по вакансии Эксперта
                </div>
              </div>
              <div className="space-y-6">
                <AIChatBot />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Greeting Video Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center mb-12">
             <h2 className="text-3xl font-black uppercase mb-4">Навигация по разделам</h2>
             <p className="text-slate-500">Узнайте больше о нашей внутренней кухне</p>
          </div>
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-effect p-8 rounded-[40px] border border-white/10 space-y-6 group hover:border-yellow-500/50 transition-all duration-500">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-2xl flex items-center justify-center text-yellow-500">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              </div>
              <h3 className="text-3xl font-black uppercase">Работа</h3>
              <div className="grid grid-cols-2 gap-4">
                {NAVIGATION_STRUCTURE.work.map((item, i) => (
                  <button 
                    key={i} 
                    onClick={() => navigateTo(item)}
                    className="text-slate-500 hover:text-white transition-colors flex items-center gap-2 text-sm font-bold text-left"
                  >
                    <span className="w-1 h-1 bg-yellow-500 rounded-full"></span>
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div className="glass-effect p-8 rounded-[40px] border border-white/10 space-y-6 group hover:border-blue-500/50 transition-all duration-500">
              <div className="w-12 h-12 bg-blue-600/20 rounded-2xl flex items-center justify-center text-blue-400">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
              </div>
              <h3 className="text-3xl font-black uppercase">Условия</h3>
              <div className="grid grid-cols-2 gap-4">
                {NAVIGATION_STRUCTURE.conditions.map((item, i) => (
                  <button 
                    key={i} 
                    onClick={() => navigateTo(item)}
                    className="text-slate-500 hover:text-white transition-colors flex items-center gap-2 text-sm font-bold text-left"
                  >
                    <span className="w-1 h-1 bg-blue-500 rounded-full"></span>
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <VacancyCard />

      {/* Final Application Form */}
      <section id="apply" className="py-32 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-yellow-500/5 blur-[150px] pointer-events-none"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-2xl mx-auto glass-effect p-12 rounded-[48px] border border-white/10 shadow-3xl">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black uppercase mb-4 tracking-tighter">Стать Экспертом</h2>
              <p className="text-slate-400">Оставь свои контакты, мы свяжемся с тобой для интервью.</p>
            </div>
            
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <input type="text" placeholder="Ваше Имя" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-yellow-500 transition-all" required />
              <div className="grid grid-cols-2 gap-4">
                <input type="text" placeholder="Telegram" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-yellow-500 transition-all" required />
                <input type="tel" placeholder="Телефон" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-yellow-500 transition-all" required />
              </div>
              <input type="url" placeholder="Ссылка на резюме" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-yellow-500 transition-all" required />
              <textarea placeholder="Ваши главные достижения..." className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 h-32 resize-none focus:outline-none focus:border-yellow-500 transition-all"></textarea>
              <button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-400 text-black py-5 rounded-2xl font-black text-xl shadow-xl shadow-yellow-500/20 transition-all transform hover:scale-[1.02]">
                ОТПРАВИТЬ ОТКЛИК
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );

  const renderContentPage = (path: string) => {
    const data = PAGE_CONTENT[path as keyof typeof PAGE_CONTENT];
    if (!data) return renderHome();

    return (
      <section className="pt-32 pb-24 min-h-[70vh]">
        <div className="container mx-auto px-6">
          <button 
            onClick={() => navigateTo('главная')} 
            className="flex items-center gap-2 text-sm font-bold text-yellow-500 mb-12 hover:translate-x-[-4px] transition-transform"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
            НАЗАД
          </button>
          
          <div className="max-w-4xl mx-auto space-y-12">
            <div className="space-y-4">
               <h1 className="text-5xl font-black uppercase tracking-tighter text-white">{data.title}</h1>
               <p className="text-xl text-slate-400 font-medium">{data.description}</p>
            </div>

            <div className="grid gap-8">
              {data.sections.map((section, idx) => (
                <div key={idx} className="glass-effect p-10 rounded-[40px] border border-white/10">
                  <h3 className="text-2xl font-black uppercase mb-6 text-yellow-500">{section.heading}</h3>
                  {section.text && <p className="text-slate-300 leading-relaxed text-lg">{section.text}</p>}
                  {section.list && (
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                      {section.list.map((item, i) => (
                        <li key={i} className="flex gap-3 text-slate-400 font-medium">
                          <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-12 text-center">
               <button 
                 onClick={handleApplyClick}
                 className="px-12 py-5 bg-white/5 border border-white/10 rounded-full font-black uppercase hover:bg-white/10 transition-all"
               >
                 Вернуться к отклику
               </button>
            </div>
          </div>
        </div>
      </section>
    );
  };

  return (
    <Layout onNavigate={navigateTo}>
      <div className="transition-all duration-300">
        {currentPath === 'главная' ? renderHome() : renderContentPage(currentPath)}
      </div>
    </Layout>
  );
};

export default App;
