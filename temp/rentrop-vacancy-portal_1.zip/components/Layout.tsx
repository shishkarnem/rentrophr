
import React, { useState } from 'react';
import { SOCIAL_LINKS, NAVIGATION_STRUCTURE } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  onNavigate: (path: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, onNavigate }) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const navigateToHome = () => {
    onNavigate('главная');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <header className="fixed top-0 w-full z-50 glass-effect border-b border-white/10">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <button 
            onClick={navigateToHome}
            className="text-2xl font-black tracking-tighter flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 bg-yellow-500 rounded flex items-center justify-center">
              <span className="text-black text-[10px] font-bold">RP</span>
            </div>
            <span className="text-white uppercase text-xl sm:text-2xl">РентРОП <span className="text-yellow-500">HR</span></span>
          </button>
          
          <nav className="hidden lg:flex gap-8 text-sm font-bold uppercase tracking-wider text-slate-400">
            <button onClick={navigateToHome} className="hover:text-yellow-500 transition-colors">Главная</button>
            
            {/* Работа Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setActiveDropdown('work')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="hover:text-yellow-500 transition-colors flex items-center gap-1">
                Работа
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
              </button>
              <div className={`absolute top-full left-0 mt-2 w-48 bg-slate-900 border border-white/10 rounded-xl shadow-2xl py-2 transition-all duration-200 ${activeDropdown === 'work' ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible translate-y-2'}`}>
                {NAVIGATION_STRUCTURE.work.map((item) => (
                  <button
                    key={item}
                    onClick={() => { onNavigate(item); setActiveDropdown(null); }}
                    className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 hover:text-yellow-500 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            {/* Условия Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setActiveDropdown('conditions')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="hover:text-yellow-500 transition-colors flex items-center gap-1">
                Условия
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
              </button>
              <div className={`absolute top-full left-0 mt-2 w-48 bg-slate-900 border border-white/10 rounded-xl shadow-2xl py-2 transition-all duration-200 ${activeDropdown === 'conditions' ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible translate-y-2'}`}>
                {NAVIGATION_STRUCTURE.conditions.map((item) => (
                  <button
                    key={item}
                    onClick={() => { onNavigate(item); setActiveDropdown(null); }}
                    className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 hover:text-yellow-500 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <a href="#vacancy" className="hover:text-yellow-500 transition-colors">Вакансия</a>
          </nav>

          <div className="flex items-center gap-4">
            <a 
              href={SOCIAL_LINKS.telegram} 
              target="_blank"
              className="hidden sm:flex text-slate-400 hover:text-blue-400 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
            </a>
            <a 
              href="#apply" 
              className="bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-2 rounded-full text-sm font-black transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-yellow-500/20"
            >
              ОТКЛИК
            </a>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-slate-900 border-t border-white/5 py-16">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-12">
            <div className="text-center md:text-left">
              <div className="text-2xl font-black mb-4 uppercase tracking-tighter">РентРОП <span className="text-yellow-500">HR</span></div>
              <p className="text-slate-500 text-sm max-w-xs">Системно строим отделы продаж и управляем ими на результат с 2019 года.</p>
            </div>
            
            <div className="flex gap-6">
              <a href={SOCIAL_LINKS.telegram} className="p-3 bg-white/5 rounded-2xl hover:bg-blue-600/20 transition-all border border-white/5 group">
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/82/Telegram_logo.svg" className="w-6 h-6 grayscale group-hover:grayscale-0 transition-all" alt="TG" />
              </a>
              <a href={SOCIAL_LINKS.youtube} className="p-3 bg-white/5 rounded-2xl hover:bg-red-600/20 transition-all border border-white/5 group">
                <img src="https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg" className="w-6 h-6 grayscale group-hover:grayscale-0 transition-all" alt="YT" />
              </a>
              <a href={SOCIAL_LINKS.vk} className="p-3 bg-white/5 rounded-2xl hover:bg-blue-500/20 transition-all border border-white/5 group">
                <img src="https://upload.wikimedia.org/wikipedia/commons/f/f3/VK_Compact_Logo_%282021-present%29.svg" className="w-6 h-6 grayscale group-hover:grayscale-0 transition-all" alt="VK" />
              </a>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-white/5 text-center text-slate-600 text-[10px] uppercase font-bold tracking-widest">
            © 2024 РентРОП. Мы строим продажи — вы строите будущее.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
