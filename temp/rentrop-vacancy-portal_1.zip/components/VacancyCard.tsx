
import React from 'react';
import { RENTROP_VACANCY } from '../constants';

const VacancyCard: React.FC = () => {
  return (
    <div id="vacancy" className="py-24 bg-slate-900/40">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div className="mb-16 text-center space-y-4">
            <h2 className="text-4xl sm:text-5xl font-black uppercase tracking-tighter">Детали позиции</h2>
            <div className="h-1 w-24 bg-yellow-500 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="glass-effect p-10 rounded-[40px] border border-white/10">
                <h3 className="text-2xl font-black uppercase mb-8 flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-yellow-500 flex items-center justify-center text-black text-sm">01</span>
                  Ваши задачи
                </h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {RENTROP_VACANCY.responsibilities.map((item, i) => (
                    <li key={i} className="flex gap-4 text-slate-300 text-sm leading-relaxed">
                      <div className="mt-1.5 flex-shrink-0 w-2 h-2 rounded-full bg-yellow-500/50"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="glass-effect p-10 rounded-[40px] border border-white/10">
                <h3 className="text-2xl font-black uppercase mb-8 flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center text-white text-sm">02</span>
                  Требования
                </h3>
                <ul className="space-y-4">
                  {RENTROP_VACANCY.requirements.map((item, i) => (
                    <li key={i} className="flex gap-4 text-slate-300 text-sm leading-relaxed">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="glass-effect p-10 rounded-[40px] border border-yellow-500/20 bg-yellow-500/5 h-fit lg:sticky lg:top-32">
              <h3 className="text-2xl font-black uppercase mb-8">Бонусы</h3>
              <ul className="space-y-6">
                {RENTROP_VACANCY.benefits.map((item, i) => (
                  <li key={i} className="text-sm font-bold text-slate-200 border-l-2 border-yellow-500/30 pl-4">
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-12 p-6 bg-white/5 rounded-2xl border border-white/5 text-center">
                <div className="text-xs text-slate-500 uppercase mb-1">Зарплата</div>
                <div className="text-2xl font-black text-yellow-500">{RENTROP_VACANCY.salary}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VacancyCard;
