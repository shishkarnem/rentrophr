
import { GoogleGenAI } from "@google/genai";
import { RENTROP_VACANCY } from "../constants";

export const askAboutVacancy = async (userQuestion: string): Promise<string> => {
  try {
    // Initialize inside the function to ensure process.env.API_KEY is picked up correctly
    // and to follow best practices for dynamic key management.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Контекст: Ты — HR-ассистент компании "РентРОП". 
      Информация о вакансии:
      - Компания: ${RENTROP_VACANCY.company}
      - Позиция: ${RENTROP_VACANCY.title}
      - Зарплата: ${RENTROP_VACANCY.salary}
      - Обязанности: ${RENTROP_VACANCY.responsibilities.join(", ")}
      - Требования: ${RENTROP_VACANCY.requirements.join(", ")}
      - Преимущества: ${RENTROP_VACANCY.benefits.join(", ")}
      - О компании: ${RENTROP_VACANCY.description}

      Вопрос кандидата: "${userQuestion}"

      Инструкция: Ответь вежливо, профессионально и кратко. Если вопроса нет в контексте, предложи оставить заявку.`,
    });

    return response.text || "Извините, я не смог обработать ваш запрос. Попробуйте еще раз.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Произошла ошибка при связи с ИИ-ассистентом. Пожалуйста, заполните форму ниже.";
  }
};
